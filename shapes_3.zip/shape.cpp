#include "shape.h"

Shape::Shape(std::vector<double> colors_in)
{
  colors = colors_in;
  active = true;
}